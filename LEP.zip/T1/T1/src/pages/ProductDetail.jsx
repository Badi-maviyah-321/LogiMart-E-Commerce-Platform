import { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";

function ProductDetail({ cartItems, setCartItems }) {
  const { id } = useParams();
  const productId = Number(id);
  const navigate = useNavigate();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch(`https://dummyjson.com/products/${id}`)
      .then(res => res.json())
      .then(data => {
        setProduct(data);

        const stored =
          JSON.parse(localStorage.getItem("recentlyViewed")) || [];

        const updated = stored.filter(p => p.id !== data.id);
        updated.unshift({
          id: data.id,
          title: data.title,
          thumbnail: data.thumbnail,
          price: data.price
        });

        localStorage.setItem(
          "recentlyViewed",
          JSON.stringify(updated.slice(0, 3))
        );
      });
  }, [id]);

  const quantity = cartItems[productId] || 0;

  const increaseQty = () => {
    setCartItems(prev => ({
      ...prev,
      [productId]: quantity + 1
    }));
  };

  const decreaseQty = () => {
    setCartItems(prev => {
      if (quantity <= 1) {
        const updated = { ...prev };
        delete updated[productId];
        return updated;
      }
      return {
        ...prev,
        [productId]: quantity - 1
      };
    });
  };

  if (!product) return <p className="loading">Loading...</p>;

  return (
    <div className="container">
      <button className="backIcon" onClick={() => navigate(-1)}>
        ← Back
      </button>

      <div className="detailCard">
        <img src={product.thumbnail} alt={product.title} />

        <div className="detailInfo">
          <h2>{product.title}</h2>
          <p className="price">₹ {product.price}</p>
          <p className="desc">{product.description}</p>

          <div className="qtyControl">
            <button onClick={decreaseQty}>−</button>
            <span>{quantity}</span>
            <button onClick={increaseQty}>+</button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default ProductDetail;