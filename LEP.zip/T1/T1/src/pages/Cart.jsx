import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Cart({ cartItems, setCartItems }) {
  const [products, setProducts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    fetch("https://dummyjson.com/products")
      .then(res => res.json())
      .then(data => setProducts(data.products));
  }, []);

  const cartProducts = products.filter(p => cartItems[p.id]);

  const increaseQty = id => {
    setCartItems(prev => ({
      ...prev,
      [id]: prev[id] + 1
    }));
  };

  const decreaseQty = id => {
    setCartItems(prev => {
      if (prev[id] <= 1) {
        const updated = { ...prev };
        delete updated[id];
        return updated;
      }
      return {
        ...prev,
        [id]: prev[id] - 1
      };
    });
  };

  if (cartProducts.length === 0) {
    return (
      <div className="container">
        <button className="backIcon" onClick={() => navigate(-1)}>
          ← Back
        </button>
        <h2 className="title">Your cart is empty</h2>
      </div>
    );
  }

  return (
    <div className="container">
      <button className="backIcon" onClick={() => navigate(-1)}>
        ← Back to Products
      </button>

      <h1 className="title">Your Cart</h1>

      {/* SAME GRID AS HOME */}
      <div className="products">
        {cartProducts.map(product => (
          <div key={product.id} className="card">
            <img
              src={product.thumbnail}
              alt={product.title}
              onClick={() => navigate(`/product/${product.id}`)}
            />

            <h3>{product.title}</h3>
            <p>₹ {product.price}</p>

            <div className="qtyControl">
              <button onClick={() => decreaseQty(product.id)}>−</button>
              <span>{cartItems[product.id]}</span>
              <button onClick={() => increaseQty(product.id)}>+</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default Cart;