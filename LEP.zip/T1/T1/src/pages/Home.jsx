import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import ProductCard from "../components/ProductCard";

function Home({ cartItems, setCartItems }) {
  const [products, setProducts] = useState([]);
  const [recent, setRecent] = useState([]);
  const [search, setSearch] = useState("");
  const [minPrice, setMinPrice] = useState("");
  const [maxPrice, setMaxPrice] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    fetch("https://dummyjson.com/products")
      .then(res => res.json())
      .then(data => setProducts(data.products));

    const stored =
      JSON.parse(localStorage.getItem("recentlyViewed")) || [];
    setRecent(stored);
  }, []);

  const addOneItem = id => {
    setCartItems(prev => {
      if (prev[id]) return prev;
      return { ...prev, [id]: 1 };
    });
  };

  const filteredProducts = products.filter(product => {
    const matchSearch = product.title
      .toLowerCase()
      .includes(search.toLowerCase());

    const matchMin =
      minPrice === "" || product.price >= Number(minPrice);

    const matchMax =
      maxPrice === "" || product.price <= Number(maxPrice);

    return matchSearch && matchMin && matchMax;
  });

  return (
    <div className="container">
      <h1 className="title">LogiMart E-Commerce Platform</h1>

      <div className="filterWrapper">
        <div className="filterBar">
          <input
            type="text"
            placeholder="Search products"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />

          <input
            type="number"
            placeholder="Min Price"
            value={minPrice}
            onChange={e => setMinPrice(e.target.value)}
          />

          <input
            type="number"
            placeholder="Max Price"
            value={maxPrice}
            onChange={e => setMaxPrice(e.target.value)}
          />
        </div>
      </div>

      {recent.length > 0 && (
        <div className="recentSection">
          <h2 className="recentTitle">Recently Viewed</h2>

          <div className="recentGrid">
            {recent.map(item => (
              <div
                key={item.id}
                className="recentCard"
                onClick={() => navigate(`/product/${item.id}`)}
              >
                <img src={item.thumbnail} alt={item.title} />
                <p>{item.title}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      <div className="products">
        {filteredProducts.length === 0 ? (
          <p className="loading">No products found</p>
        ) : (
          filteredProducts.map(product => (
            <ProductCard
              key={product.id}
              product={product}
              isAdded={!!cartItems[product.id]}
              addOneItem={addOneItem}
            />
          ))
        )}
      </div>
    </div>
  );
}

export default Home;