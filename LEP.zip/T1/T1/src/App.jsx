import { BrowserRouter, Routes, Route } from "react-router-dom";
import { useEffect, useState } from "react";
import Home from "./pages/Home";
import ProductDetail from "./pages/ProductDetail";
import Cart from "./pages/Cart";
import Header from "./components/Header";
import "./App.css";

function App() {
  const [cartItems, setCartItems] = useState(() => { 
    return JSON.parse(localStorage.getItem("cartItems")) || {};
  });

  useEffect(() => {
    localStorage.setItem("cartItems", JSON.stringify(cartItems));
  }, [cartItems]);

  const cartCount = Object.values(cartItems).reduce(
    (total, qty) => total + qty,
    0
  );

  return (
    <BrowserRouter>
      <Header cartCount={cartCount} />
      <Routes>
        <Route
          path="/"
          element={<Home cartItems={cartItems} setCartItems={setCartItems} />}
        />
        <Route
          path="/product/:id"
          element={
            <ProductDetail
              cartItems={cartItems}
              setCartItems={setCartItems}
            />
          }
        />
        <Route
          path="/cart"
          element={<Cart cartItems={cartItems} setCartItems={setCartItems} />}
        />
      </Routes>
    </BrowserRouter>
  );
}

export default App;