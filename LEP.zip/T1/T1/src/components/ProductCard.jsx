import { useNavigate } from "react-router-dom";

function ProductCard({ product, isAdded, addOneItem }) {
  const navigate = useNavigate();

  return (
    <div className="card">
      <img
        src={product.thumbnail}
        alt={product.title}
        onClick={() => navigate(`/product/${product.id}`)}
      />

      <h3>{product.title}</h3>
      <p>₹ {product.price}</p>

      <button
        className={isAdded ? "addedBtn" : ""}
        onClick={() => addOneItem(product.id)}
      >
        {isAdded ? "Added" : "Add to Cart"}
      </button>
    </div>
  );
}

export default ProductCard;