import { Link } from "react-router-dom";

function Header({ cartCount }) {
  return (
    <header className="header">
      <Link to="/" className="logo">
        LEP Store
      </Link>

      <Link to="/cart" className="cart">
        Cart <span>{cartCount}</span>
      </Link>
    </header>
  );
}

export default Header;