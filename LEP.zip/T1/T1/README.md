# LogiMart E-Commerce Platform (LEP Store)

*A storefront built not just with code, but with care.*

LogiMart (LEP Store) is a frontend e-commerce web application developed using **ReactJS** as part of my internship task.  
The core intention behind this project was to design a **clean, responsive, and intuitive user interface** while ensuring smooth client-side functionality and well-structured React logic.

---

## Technologies Used

- **ReactJS** (Functional Components)
- **React Hooks** (`useState`, `useEffect`)
- **React Router DOM**
- **Vanilla CSS**
- **DummyJSON Public API**
- **localStorage**

---

## Features

### Product Listing
- Products fetched dynamically from the **DummyJSON API**
- Displayed in a responsive grid layout
- Clean, consistent product cards for a marketplace feel

###  Search & Price Filter
- Real-time search by product name
- Filter products using **minimum** and **maximum** price
- Filters work together seamlessly (no tug-of-war between logic)

### Product Detail Page
- Dynamic routing using product ID
- Displays complete product details
- Quantity adjustment using **+ / −** controls
- Add or remove products from the cart

### Cart Functionality
- Add and remove products from the cart
- Quantity management per item
- Cart state shared across all pages
- Persistent cart data using **localStorage**

### Recently Viewed Products
- Displays the **last 3 unique products** viewed
- Data persists even after page refresh
- Stored using **localStorage**
- Clickable items to revisit product details

### UI / UX & Responsiveness
- Clean, marketplace-style UI
- Light blue and mint background palette
- White product cards with soft shadows
- Fully responsive across **mobile, tablet, and desktop**

---

## Project Structure

src/
│
├── components/
│   ├── Header.jsx
│   └── ProductCard.jsx
│
├── pages/
│   ├── Home.jsx
│   ├── ProductDetail.jsx
│   └── Cart.jsx
│
├── App.js
├── App.css
└── main.jsx
---

## How to Run the Project

1. **Clone the repository**

      git clone <your-github-repository-link>
   

2. **Navigate to the project folder**

   cd logimart
   
3. **Install dependencies**

   
   npm install
   
4. **Start the development server**

      npm start

5. **Open in browser**

   http://localhost:5173/

---

## Evaluation Criteria Mapping

### **45% — UI / UX Design & Responsiveness**

* Clean layout
* Responsive design
* Consistent UI across all pages

### **35% — Functional Completion**

* Search functionality
* Price filtering
* Cart logic
* Recently viewed products
* localStorage usage

### **20% — Code Quality**

* Functional components
* Effective use of hooks
* Reusable and modular components

---

## Conclusion

This project reflects my understanding of **React fundamentals**, **component-based architecture**, and **frontend UI/UX principles**.
It fulfills the internship task requirements while maintaining clarity, responsiveness, and maintainable code—no magic, just discipline.

---

## Author

**Maviyah**

